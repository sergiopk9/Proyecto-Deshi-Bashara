package tienda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BDController {

	private Connection conexion;

	public BDController() {
		super();
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			this.conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/LaChapuzza", "root", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error en Constructor BDController: " + e.getMessage());
		}
	}

	public Connection getConexion() {
		return conexion;
	}

	public void setConexion(Connection conexion) {
		this.conexion = conexion;
	}




}
